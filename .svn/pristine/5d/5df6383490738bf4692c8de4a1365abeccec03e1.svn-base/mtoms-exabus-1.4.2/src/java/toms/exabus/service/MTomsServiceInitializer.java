package toms.exabus.service;

import msgrouter.engine.Service;
import msgrouter.engine.ServiceInitializer;

import org.apache.log4j.Logger;

public class MTomsServiceInitializer implements ServiceInitializer {
	private static final Logger LOG = Logger
			.getLogger(MTomsServiceInitializer.class);

	private Service service = null;

	public void setService(Service service) throws Exception {
		this.service = service;
	}

	public void execute() throws Exception {
	}
}
