package toms.exabus.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import msgrouter.adapter.json.JSONMessage;
import msgrouter.api.SyncQueue;
import msgrouter.api.interfaces.bean.SyncBean;
import msgrouter.engine.MsgRouter;
import msgrouter.engine.SessionContext;

import org.apache.log4j.Logger;

import toms.exabus.service.outtable.db.OutDstTableConst;
import toms.exabus.service.outtable.db.OutMsgTableConst;
import elastic.util.beanmgr.BeanMgr;
import elastic.util.dataset.DataSet;
import elastic.util.dataset.Row;
import elastic.util.json.JSONArray;
import elastic.util.json.JSONObject;
import elastic.util.sqlmgr.SqlConn;
import elastic.util.sqlmgr.SqlConnPool;
import elastic.util.sqlmgr.SqlMgrUtil;
import elastic.util.sqlmgr.dataset.DBRow;
import elastic.util.util.BizException;
import elastic.util.util.ErrorCodeMgr;
import elastic.util.util.ExceptionDetail;
import elastic.util.util.TechException;

public class SequencialSendCronjob extends SyncBean {
	private static final long serialVersionUID = -6038574782646488151L;

	private static final Logger LOG = Logger
			.getLogger(SequencialSendCronjob.class);

	public static final String MSG_TYPE_OUT_TABLE_REQ = "outTableReq";

	private final String connPoolName;
	private final SendInfo sendInfo;
	private ErrorCodeMgr errorCodeMgr = null;

	private SessionContext context = null;

	public SequencialSendCronjob(String connPoolName, SendInfo sendInfo) {
		this.connPoolName = connPoolName;
		this.sendInfo = sendInfo;

		this.errorCodeMgr = (ErrorCodeMgr) BeanMgr.getInstance().get(
				"errorCodeMgr");
	}

	public void setSessionContext(SessionContext context) {
		this.context = context;
	}

	public void execute(SyncQueue syncQ) throws TechException {
		SqlConn sqlConn = null;

		try {
			SqlConnPool connPool = MsgRouter.getInstance().getSqlConnPool(
					connPoolName);
			sqlConn = connPool.getSqlConn();

			Row param = new DBRow();
			DataSet rRows = sqlConn.queryList(sendInfo.getLastSeqnosSqlId(),
					param);

			for (int msgIdx = 0; msgIdx < rRows.size(); msgIdx++) {
				Row rRow = (Row) rRows.get(msgIdx);
				int targetSeqno = rRow.getInt("SEQNO");
				String availYN = rRow.getString("AVAIL_YN");
				if (!"Y".equals(availYN)) {
					continue;
				}
				rRow.put(sendInfo.getSeqnoColName(), targetSeqno);

				List<List<Map>> remoteSqlParams = sendInfo
						.getRemoteSqlParamRecords(sqlConn, (Map) rRow);
				JSONArray recordsJSON = SqlMgrUtil.listToJSON(remoteSqlParams);

				JSONObject sqlExecMapJSON = new JSONObject();
				sqlExecMapJSON.put("sqlId", sendInfo.getRemoteSqlId());
				sqlExecMapJSON.put("records", recordsJSON);

				JSONMessage oMsg = new JSONMessage();
				oMsg.setMessageType("MSG_TYPE_OUT_TABLE_REQ");
				oMsg.set(OutMsgTableConst.COL_SEQ_NO, targetSeqno);
				oMsg.set(OutMsgTableConst.COL_MSG, sqlExecMapJSON.toString());

				syncQ.send(oMsg);
				if (LOG.isTraceEnabled()) {
					LOG.trace("sent " + sendInfo.getSeqnoColName() + "="
							+ targetSeqno);
				}

				int tryCnt = 0;
				boolean recved = false;
				do {
					tryCnt++;
					JSONMessage iMsg = (JSONMessage) syncQ.recv();
					Integer resSeqNo = iMsg
							.getInteger(OutMsgTableConst.COL_SEQ_NO);
					String stat = (String) iMsg.get(OutDstTableConst.COL_STAT);
					String errCd = (String) iMsg
							.get(OutDstTableConst.COL_ERR_CD);
					String errMsg = (String) iMsg
							.get(OutDstTableConst.COL_ERR_MSG);

					if (LOG.isTraceEnabled()) {
						LOG.trace("recv " + sendInfo.getSeqnoColName() + "="
								+ resSeqNo + ": stat=" + stat + ", errCd="
								+ errCd + ", errMsg=" + errMsg);
					}
					if (resSeqNo == targetSeqno) {
						recved = true;
						if (!OutDstTableConst.VAL_STAT_FAIL.equals(stat)) {
							updateLastSeqno(sqlConn, resSeqNo);
							break;
						} else {
							LOG.error("fail to upload "
									+ sendInfo.getSeqnoColName() + "="
									+ resSeqNo + ": " + errCd + ": " + errMsg);
							return;
						}
					}
				} while (!recved && tryCnt < 3);
			}
		} catch (BizException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} catch (Throwable e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} finally {
			if (sqlConn != null) {
				sqlConn.close();
			}
		}
	}

	public void updateLastSeqno(SqlConn sqlConn, int seqno)
			throws BizException, TechException, SQLException {
		Row pRow = new DBRow();
		pRow.put("SEQNO", seqno);
		sqlConn.queryUpdate(sendInfo.getUpdateLastSeqnoSqlId(), pRow);
	}
}
