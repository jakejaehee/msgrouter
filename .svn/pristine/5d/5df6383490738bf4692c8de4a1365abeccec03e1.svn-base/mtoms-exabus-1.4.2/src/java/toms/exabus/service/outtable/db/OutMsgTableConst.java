package toms.exabus.service.outtable.db;

public class OutMsgTableConst {

	public static final String COL_SEQ_NO = "SEQ_NO";
	public static final String COL_DST_IDS = "DST_IDS";
	public static final String COL_MSG_TYPE = "MSG_TYPE";
	public static final String COL_MSG = "MSG";
	public static final String COL_MSG_REG_DT = "MSG_REG_DT";
	public static final String COL_ASSIGN_STAT = "ASSIGN_STAT";

	public static final String VAL_ASSIGN_STAT_INIT = "I";
	public static final String VAL_ASSIGN_STAT_ASSIGN = "A";
	public static final String VAL_ASSIGN_STAT_BACK = "B";

	public static final String KEY_OUT_MSG_TABLE = "OUT_MSG_TABLE";
	public static final String VAL_OUT_MSG_TABLE = "T_EXABUS_OUT_MSG_H";
}
