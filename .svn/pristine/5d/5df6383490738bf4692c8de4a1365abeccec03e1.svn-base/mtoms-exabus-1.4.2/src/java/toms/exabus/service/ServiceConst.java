package toms.exabus.service;

public class ServiceConst {
	public static final String BEAN_SQL_CONN_POOL_MGR = "sqlConnPoolMgr";
	public static final String VAL_SQL_CONN_POOL = "default";

	public static final String MSG_TYPE_OUT_TABLE_REQ = "outTableReq";
	public static final String MSG_TYPE_OUT_TABLE_RES = "outTableRes";

	public static final String MSG_TYPE_TOM10_SAL_SEND_REQ = "toms10SalSendReq";
	public static final String MSG_TYPE_TOM10_SAL_SEND_RES = "toms10SalSendRes";
}
