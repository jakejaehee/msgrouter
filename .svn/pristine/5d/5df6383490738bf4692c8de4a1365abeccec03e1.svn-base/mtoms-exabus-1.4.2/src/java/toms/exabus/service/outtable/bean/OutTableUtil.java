package toms.exabus.service.outtable.bean;

import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.Logger;

import toms.exabus.service.outtable.db.OutDstTableConst;
import toms.exabus.service.outtable.db.OutMsgTableConst;
import elastic.util.sqlmgr.SqlConn;
import elastic.util.sqlmgr.dataset.DBRow;

public class OutTableUtil {
	private static final Logger LOG = Logger.getLogger(OutTableUtil.class);

	static boolean existsOutMsgTable(SqlConn sqlConn, String outMsgTable) {
		Map pRecord = new DBRow();
		pRecord.put(OutMsgTableConst.KEY_OUT_MSG_TABLE, outMsgTable);

		try {
			ArrayList<Map> rRecords = sqlConn.queryList(
					"outTable.existsOutMsgTable", pRecord);
		} catch (Exception e) {
			return false;
		} catch (Error e) {
			return false;
		}
		return true;
	}

	static boolean existsOutDstTable(SqlConn sqlConn, String outDstTable) {
		Map pRecord = new DBRow();
		pRecord.put(OutDstTableConst.KEY_OUT_DST_TABLE, outDstTable);

		try {
			ArrayList<Map> rRecords = sqlConn.queryList(
					"outTable.existsOutDstTable", pRecord);
		} catch (Exception e) {
			return false;
		} catch (Error e) {
			return false;
		}
		return true;
	}

	static void createOutMsgTable(SqlConn sqlConn, String outMsgTable,
			String outDstTable) {
		Map pRecord = new DBRow();
		pRecord.put(OutMsgTableConst.KEY_OUT_MSG_TABLE, outMsgTable);
		pRecord.put(OutDstTableConst.KEY_OUT_DST_TABLE, outDstTable);

		// CREATE MSG TABLE AND IDX1, IDX2
		try {
			sqlConn.queryUpdate("outTable.createOutMsgTable", pRecord);
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
		try {
			sqlConn.queryUpdate("outTable.createOutMsgTableIdx1", pRecord);
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
		try {
			sqlConn.queryUpdate("outTable.createOutMsgTableIdx2", pRecord);
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
	}

	static void createOutDstTable(SqlConn sqlConn, String outMsgTable,
			String outDstTable) {
		Map pRecord = new DBRow();
		pRecord.put(OutMsgTableConst.KEY_OUT_MSG_TABLE, outMsgTable);
		pRecord.put(OutDstTableConst.KEY_OUT_DST_TABLE, outDstTable);

		// CREATE DST TABLE AND IDX1, IDX2, IDX3
		try {
			sqlConn.queryUpdate("outTable.createOutDstTable", pRecord);
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
		try {
			sqlConn.queryUpdate("outTable.createOutDstTableIdx1", pRecord);
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
		try {
			sqlConn.queryUpdate("outTable.createOutDstTableIdx2", pRecord);
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
		try {
			sqlConn.queryUpdate("outTable.createOutDstTableIdx3", pRecord);
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
	}
}
