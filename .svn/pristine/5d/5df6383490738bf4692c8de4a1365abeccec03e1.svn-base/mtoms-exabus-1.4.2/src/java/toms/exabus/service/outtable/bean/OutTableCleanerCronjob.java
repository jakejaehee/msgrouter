package toms.exabus.service.outtable.bean;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import msgrouter.api.QueueEntry;
import msgrouter.api.interfaces.Message;
import msgrouter.api.interfaces.bean.AsyncBean;
import msgrouter.engine.SessionContext;

import org.apache.log4j.Logger;

import toms.exabus.service.ServiceConst;
import toms.exabus.service.outtable.db.OutDstTableConst;
import toms.exabus.service.outtable.db.OutMsgTableConst;
import elastic.util.beanmgr.BeanMgr;
import elastic.util.concurrent.LockMgr;
import elastic.util.sqlmgr.SqlConn;
import elastic.util.sqlmgr.SqlConnPool;
import elastic.util.sqlmgr.SqlConnPoolManager;
import elastic.util.sqlmgr.dataset.DBRow;
import elastic.util.util.BizException;
import elastic.util.util.DateUtil;
import elastic.util.util.ErrorCodeMgr;
import elastic.util.util.ExceptionDetail;
import elastic.util.util.TechException;

public class OutTableCleanerCronjob extends AsyncBean {
	private static final Logger LOG = Logger
			.getLogger(OutTableCleanerCronjob.class);

	private final OutTableEnv env;
	private SessionContext context = null;
	private ErrorCodeMgr errorCodeMgr = null;

	public OutTableCleanerCronjob() {
		this.env = (OutTableEnv) BeanMgr.getInstance().get("outTableEnv");
		this.errorCodeMgr = (ErrorCodeMgr) BeanMgr.getInstance().get(
				"errorCodeMgr");

		SqlConn sqlConn = null;
		try {
			SqlConnPoolManager conPoolMgr = (SqlConnPoolManager) BeanMgr
					.getInstance().get(ServiceConst.BEAN_SQL_CONN_POOL_MGR);
			SqlConnPool connPool = conPoolMgr.getSqlConnPool(env.connPoolName);
			sqlConn = connPool.getSqlConn();

			if (!OutTableUtil.existsOutMsgTable(sqlConn, env.outMsgTable)) {
				OutTableUtil.createOutMsgTable(sqlConn, env.outMsgTable,
						env.outDstTable);
			}
			if (!OutTableUtil.existsOutDstTable(sqlConn, env.outDstTable)) {
				OutTableUtil.createOutDstTable(sqlConn, env.outMsgTable,
						env.outDstTable);
			}
		} catch (SQLException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} finally {
			if (sqlConn != null) {
				sqlConn.close();
			}
		}
	}

	public void setSessionContext(SessionContext context) {
		this.context = context;
	}

	public QueueEntry onMessage(Message msg) throws TechException {
		return null;
	}

	public QueueEntry onCronjob() throws TechException {
		SqlConn sqlConn = null;
		LockMgr lockMgr = context.getService().getLockMgr();

		try {
			SqlConnPoolManager conPoolMgr = (SqlConnPoolManager) BeanMgr
					.getInstance().get(ServiceConst.BEAN_SQL_CONN_POOL_MGR);
			SqlConnPool connPool = conPoolMgr.getSqlConnPool(env.connPoolName);
			sqlConn = connPool.getSqlConn();

			String bakSn = DateUtil.getDateString("yyyyMMdd_HHmm");
			Map param = new DBRow();
			param.put(OutMsgTableConst.KEY_OUT_MSG_TABLE, env.outMsgTable);
			param.put(OutDstTableConst.KEY_OUT_DST_TABLE, env.outDstTable);
			param.put("BAK_SN", bakSn);

			List<Map> rRecords = sqlConn.queryList("outTable.countDstRow",
					param);
			if (rRecords != null && rRecords.size() > 0) {
				Map rRecord = rRecords.get(0);
				Integer dstRowCnt = (Integer) rRecord.get("DST_ROW_CNT");
				if (dstRowCnt < env.maxDstTableRowsToClean) {
					return null;
				}
			}

			lockMgr.lock(env.outMsgTable);
			if (LOG.isTraceEnabled()) {
				LOG.trace("locked table: " + env.outMsgTable);
			}
			try {
				Thread.sleep(10000);
			} catch (Exception e) {
			}

			// DROP DST TABLE's PK, FK, IDX1, IDX2, IDX3 AND RENAME DST TABLE
			try {
				sqlConn.queryUpdate("outTable.dropOutDstTablePK", param);
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}
			try {
				sqlConn.queryUpdate("outTable.dropOutDstTableFK", param);
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}
			try {
				sqlConn.queryUpdate("outTable.dropOutDstTableIdx1", param);
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}
			try {
				sqlConn.queryUpdate("outTable.dropOutDstTableIdx2", param);
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}
			try {
				sqlConn.queryUpdate("outTable.dropOutDstTableIdx3", param);
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}
			try {
				sqlConn.queryUpdate("outTable.renameOutDstTable", param);
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}

			// DROP MSG TABLE's PK, IDX1, IDX2 AND RENAME MSG TABLE
			try {
				sqlConn.queryUpdate("outTable.dropOutMsgTablePK", param);
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}
			try {
				sqlConn.queryUpdate("outTable.dropOutMsgTableIdx1", param);
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}
			try {
				sqlConn.queryUpdate("outTable.dropOutMsgTableIdx2", param);
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}
			try {
				sqlConn.queryUpdate("outTable.renameOutMsgTable", param);
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}

			OutTableUtil.createOutMsgTable(sqlConn, env.outMsgTable,
					env.outDstTable);
			OutTableUtil.createOutDstTable(sqlConn, env.outMsgTable,
					env.outDstTable);

			restoreBakMsg(sqlConn, bakSn);
		} catch (BizException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} catch (TechException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} catch (SQLException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} finally {
			if (lockMgr.isLocked(env.outMsgTable)) {
				lockMgr.unlock(env.outMsgTable);
				if (LOG.isTraceEnabled()) {
					LOG.trace("unlocked table: " + env.outMsgTable);
				}
			}

			if (sqlConn != null) {
				sqlConn.close();
			}
		}
		return null;
	}

	private void restoreBakMsg(SqlConn sqlConn, String bakSn)
			throws BizException, TechException, SQLException {
		Map param = new DBRow();
		param.put(OutMsgTableConst.KEY_OUT_MSG_TABLE, env.outMsgTable);
		param.put(OutDstTableConst.KEY_OUT_DST_TABLE, env.outDstTable);
		param.put("ASSIGN_STAT_INIT", OutMsgTableConst.VAL_ASSIGN_STAT_INIT);
		param.put("ASSIGN_STAT_ASSIGN", OutMsgTableConst.VAL_ASSIGN_STAT_ASSIGN);
		param.put("ASSIGN_STAT_BACK", OutMsgTableConst.VAL_ASSIGN_STAT_BACK);
		param.put("STAT_BACK", OutDstTableConst.VAL_STAT_BACK);
		param.put("STAT_SUCC", OutDstTableConst.VAL_STAT_SUCC);
		param.put("STAT_FAIL", OutDstTableConst.VAL_STAT_FAIL);
		param.put("BAK_SN", bakSn);

		while (true) {
			List<Map> rRecords = sqlConn.queryList("outTable.selectRestoreMsg",
					param);
			if (rRecords == null || rRecords.size() == 0) {
				break;
			}

			ArrayList<SeqNoSet> seqNoList = new ArrayList<SeqNoSet>();

			int size = rRecords.size();
			for (int msgIdx = 0; msgIdx < size; msgIdx++) {
				Map result = rRecords.get(msgIdx);
				result.putAll(param);

				sqlConn.startTransaction();

				Integer bakSeqNo = (Integer) result.get("BAK_SEQ_NO");
				int seqNoListSize = seqNoList.size();
				int seqNoIdx = 0;
				for (; seqNoIdx < seqNoListSize; seqNoIdx++) {
					SeqNoSet tmp = seqNoList.get(seqNoIdx);
					if (bakSeqNo.equals(tmp.getBakSeqNo())) {
						break;
					}
				}

				Integer seqNo = null;

				if (seqNoIdx == seqNoListSize) {
					List<Map> tmpRecords = sqlConn.queryList(
							"outTable.insertRestoreMsg", result);
					if (tmpRecords != null && tmpRecords.size() > 0) {
						Map tmpRecord = tmpRecords.get(0);
						result.putAll(tmpRecord);

						seqNo = (Integer) result.get("SEQ_NO");

						if (LOG.isTraceEnabled()) {
							LOG.trace("insert MSG_TABLE SEQ_NO=" + seqNo
									+ ", BAK_SEQ_NO=" + bakSeqNo);
						}

						sqlConn.queryUpdate("outTable.updateBakMsgTableStat",
								result);

						SeqNoSet seqNoSet = new SeqNoSet();
						seqNoSet.setBakSeqNo(bakSeqNo);
						seqNoSet.setSeqNo(seqNo);
						seqNoList.add(seqNoSet);

						if (LOG.isTraceEnabled()) {
							LOG.trace("update BAK_MSG_TABLE BAK_SEQ_NO="
									+ bakSeqNo);
						}
					}
				}

				if (seqNo == null) {
					SeqNoSet tmp = seqNoList.get(seqNoIdx);
					seqNo = tmp.getSeqNo();
					result.put("SEQ_NO", seqNo);
				}

				String dstId = (String) result.get("DST_ID");
				if (dstId != null && !"".equals(dstId)) {
					sqlConn.queryUpdate("outTable.insertRestoreDst", result);
					if (LOG.isTraceEnabled()) {
						LOG.trace("insert dst_table SEQ_NO=" + seqNo
								+ " AND DST_ID=" + dstId);
					}

					sqlConn.queryUpdate("outTable.updateBakDstTableStat",
							result);

					if (LOG.isTraceEnabled()) {
						LOG.trace("update backup_dst_table BAK_SEQ_NO="
								+ bakSeqNo + " AND DST_ID=" + dstId);
					}
				}

				sqlConn.commit();
			}

			seqNoList.clear();

			try {
				Thread.sleep(0, 100000);
			} catch (Exception e) {
			}
		}
	}

	class SeqNoSet {
		private Integer seqNo = null;
		private Integer bakSeqNo = null;

		public Integer getSeqNo() {
			return seqNo;
		}

		public void setSeqNo(Integer seqNo) {
			this.seqNo = seqNo;
		}

		public Integer getBakSeqNo() {
			return bakSeqNo;
		}

		public void setBakSeqNo(Integer bakSeqNo) {
			this.bakSeqNo = bakSeqNo;
		}
	}
}
