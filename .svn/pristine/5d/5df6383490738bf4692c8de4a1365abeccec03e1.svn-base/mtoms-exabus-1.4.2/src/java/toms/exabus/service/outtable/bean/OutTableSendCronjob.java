package toms.exabus.service.outtable.bean;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import msgrouter.adapter.json.JSONMessage;
import msgrouter.api.QueueEntry;
import msgrouter.api.interfaces.Message;
import msgrouter.api.interfaces.bean.AsyncBean;
import msgrouter.engine.SessionContext;

import org.apache.log4j.Logger;

import toms.exabus.service.ServiceConst;
import toms.exabus.service.outtable.db.OutDstTableConst;
import toms.exabus.service.outtable.db.OutMsgTableConst;
import elastic.util.beanmgr.BeanMgr;
import elastic.util.concurrent.LockMgr;
import elastic.util.jdbc.JdbcUtil;
import elastic.util.sqlmgr.SqlConn;
import elastic.util.sqlmgr.SqlConnPool;
import elastic.util.sqlmgr.SqlConnPoolManager;
import elastic.util.sqlmgr.SqlResultSet;
import elastic.util.sqlmgr.dataset.DBRow;
import elastic.util.sqlmgr.sql.ColMapper;
import elastic.util.sqlmgr.sql.Sql;
import elastic.util.util.BizException;
import elastic.util.util.DateUtil;
import elastic.util.util.ErrorCodeMgr;
import elastic.util.util.TechException;

public class OutTableSendCronjob extends AsyncBean {
	private static final long serialVersionUID = 8008825228328436696L;

	private static final Logger LOG = Logger
			.getLogger(OutTableSendCronjob.class);

	private final OutTableEnv env;
	private SessionContext context = null;
	private ErrorCodeMgr errorCodeMgr = null;

	public OutTableSendCronjob() {
		this.env = (OutTableEnv) BeanMgr.getInstance().get("outTableEnv");
		this.errorCodeMgr = (ErrorCodeMgr) BeanMgr.getInstance().get(
				"errorCodeMgr");
	}

	public void setSessionContext(SessionContext context) {
		this.context = context;
	}

	public QueueEntry onMessage(Message msg) throws TechException {
		SqlConn sqlConn = null;
		String ackDt = DateUtil.toString(System.currentTimeMillis());

		LockMgr lockMgr = context.getService().getLockMgr();
		lockMgr.waitUnlock(env.outMsgTable);

		try {
			SqlConnPoolManager conPoolMgr = (SqlConnPoolManager) BeanMgr
					.getInstance().get(ServiceConst.BEAN_SQL_CONN_POOL_MGR);

			SqlConnPool connPool = conPoolMgr.getSqlConnPool(env.connPoolName);
			sqlConn = connPool.getSqlConn();

			Object seqNo = msg.get(OutMsgTableConst.COL_SEQ_NO);
			String dstId = (String) msg.get(OutDstTableConst.COL_DST_ID);
			if (dstId == null) {
				dstId = context.getLoginId();
			}
			String stat = (String) msg.get(OutDstTableConst.COL_STAT);
			String errCd = (String) msg.get(OutDstTableConst.COL_ERR_CD);
			String errMsg = (String) msg.get(OutDstTableConst.COL_ERR_MSG);

			Map param = new DBRow();
			param.put(OutDstTableConst.KEY_OUT_DST_TABLE, env.outDstTable);
			param.put(OutMsgTableConst.COL_SEQ_NO, seqNo);
			param.put(OutDstTableConst.COL_DST_ID, dstId);

			List<Map> dstRecordList = sqlConn.queryList("outTable.selectDst",
					param);
			if (dstRecordList != null && dstRecordList.size() != 0) {
				Map dstRecord = dstRecordList.get(0);

				if (OutDstTableConst.VAL_STAT_FAIL.equals(stat)) {
					if (env.maxSendCnt <= 0) {
						stat = OutDstTableConst.VAL_STAT_RECV;
					} else {
						int sendCnt = (Integer) dstRecord
								.get(OutDstTableConst.COL_SENT_CNT);
						if (sendCnt < env.maxSendCnt) {
							stat = OutDstTableConst.VAL_STAT_RECV;
						}
					}
				}

				param.put(OutDstTableConst.COL_STAT, stat);
				param.put(OutDstTableConst.COL_RECV_DT, ackDt);
				param.put(OutDstTableConst.COL_ERR_CD, errCd);
				param.put(OutDstTableConst.COL_ERR_MSG, errMsg);
				sqlConn.queryUpdate("outTable.setDstStatByRecvMsg", param);
			}
		} catch (Exception e) {
			throw new TechException(e);
		} finally {
			if (sqlConn != null) {
				sqlConn.close();
			}
		}
		return null;
	}

	public QueueEntry onCronjob() throws TechException {
		SqlConn sqlConn = null;

		LockMgr lockMgr = context.getService().getLockMgr();
		lockMgr.waitUnlock(env.outMsgTable);

		try {
			SqlConnPoolManager conPoolMgr = (SqlConnPoolManager) BeanMgr
					.getInstance().get(ServiceConst.BEAN_SQL_CONN_POOL_MGR);

			SqlConnPool connPool = conPoolMgr.getSqlConnPool(env.connPoolName);
			sqlConn = connPool.getSqlConn();

			QueueEntry qe = selectMsgToSend(sqlConn, env.maxSendMsg);
			return qe;
		} catch (Exception e) {
			throw new TechException(e);
		} finally {
			if (sqlConn != null) {
				sqlConn.close();
			}
		}
	}

	private QueueEntry selectMsgToSend(SqlConn sqlConn, int maxSendMsg)
			throws BizException, TechException, SQLException {
		QueueEntry qe = new QueueEntry();
		SqlResultSet srs = null;

		try {
			String dstId = context.getLoginId();

			Map selectPRecord = new DBRow();
			selectPRecord.put(OutMsgTableConst.KEY_OUT_MSG_TABLE,
					env.outMsgTable);
			selectPRecord.put(OutDstTableConst.KEY_OUT_DST_TABLE,
					env.outDstTable);
			if (dstId != null) {
				selectPRecord.put(OutDstTableConst.COL_DST_ID, dstId);
			}
			selectPRecord.put("MAX", maxSendMsg);
			selectPRecord.put("STAT_INIT", OutDstTableConst.VAL_STAT_INIT);
			selectPRecord.put("STAT_PROC", OutDstTableConst.VAL_STAT_PROC);
			selectPRecord.put("STAT_SUCC", OutDstTableConst.VAL_STAT_SUCC);
			selectPRecord.put("STAT_FAIL", OutDstTableConst.VAL_STAT_FAIL);
			selectPRecord.put(
					"RESEND_DT",
					DateUtil.toString(System.currentTimeMillis()
							- (60000 * env.resendMinutes)));

			Sql sql = sqlConn.getSql("outTable.selectMsgToSend");
			ColMapper colMapper = sql.getColMapper();

			srs = sqlConn.querySqlResultSet("outTable.selectMsgToSend",
					selectPRecord);

			if (srs != null) {
				// sqlConn.startTransaction();

				ResultSet rs = srs.getResultSet();
				ResultSetMetaData md = rs.getMetaData();

				for (int i = 0; (maxSendMsg <= 0 || i < maxSendMsg)
						&& rs.next(); i++) {
					Map row = JdbcUtil.toRow(rs, md, colMapper);
					row.put(OutDstTableConst.KEY_OUT_DST_TABLE, env.outDstTable);
					row.put(OutDstTableConst.COL_STAT,
							OutDstTableConst.VAL_STAT_PROC);
					sqlConn.queryUpdate("outTable.setProcessing", row);

					String msgType = (String) row
							.get(OutMsgTableConst.COL_MSG_TYPE);
					Object seqNo = row.get(OutMsgTableConst.COL_SEQ_NO);

					String dstExaBusId = (String) row
							.get(OutDstTableConst.COL_DST_ID);
					String msg = (String) row.get(OutMsgTableConst.COL_MSG);

					JSONMessage oMsg = new JSONMessage();
					oMsg.setMessageType(msgType);
					oMsg.set(OutMsgTableConst.COL_SEQ_NO, seqNo);
					oMsg.set(OutDstTableConst.COL_DST_ID, dstExaBusId);
					oMsg.set(OutMsgTableConst.COL_MSG, msg);
					oMsg.setDstId(dstExaBusId);

					qe.addMessage(oMsg);
				}

				// sqlConn.commit();
			}
		} finally {
			if (srs != null) {
				srs.close();
			}
		}

		return qe;
	}
}
