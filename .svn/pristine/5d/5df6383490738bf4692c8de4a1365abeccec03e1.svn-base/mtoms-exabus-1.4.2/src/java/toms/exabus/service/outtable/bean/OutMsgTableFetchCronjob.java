package toms.exabus.service.outtable.bean;

import java.sql.SQLException;
import java.util.Map;

import msgrouter.api.QueueEntry;
import msgrouter.api.interfaces.Message;
import msgrouter.api.interfaces.bean.AsyncBean;
import msgrouter.api.resource.LoginIds;
import msgrouter.engine.SessionContext;

import org.apache.log4j.Logger;

import toms.exabus.service.ServiceConst;
import toms.exabus.service.outtable.db.OutDstTableConst;
import toms.exabus.service.outtable.db.OutMsgTableConst;
import elastic.util.beanmgr.BeanMgr;
import elastic.util.concurrent.LockMgr;
import elastic.util.dataset.DataSet;
import elastic.util.sqlmgr.SqlConn;
import elastic.util.sqlmgr.SqlConnPool;
import elastic.util.sqlmgr.SqlConnPoolManager;
import elastic.util.sqlmgr.dataset.DBRow;
import elastic.util.util.BizException;
import elastic.util.util.DateUtil;
import elastic.util.util.ErrorCodeMgr;
import elastic.util.util.ExceptionDetail;
import elastic.util.util.StringUtil;
import elastic.util.util.TechException;

public class OutMsgTableFetchCronjob extends AsyncBean {
	private static final long serialVersionUID = 7165501602016777829L;

	private static final Logger LOG = Logger
			.getLogger(OutMsgTableFetchCronjob.class);

	private final OutTableEnv env;
	private ErrorCodeMgr errorCodeMgr = null;
	private SessionContext context = null;

	public OutMsgTableFetchCronjob() {
		this.env = (OutTableEnv) BeanMgr.getInstance().get("outTableEnv");
		this.errorCodeMgr = (ErrorCodeMgr) BeanMgr.getInstance().get(
				"errorCodeMgr");
	}

	public void setSessionContext(SessionContext context) {
		this.context = context;
	}

	public QueueEntry onMessage(Message msg) throws TechException {
		return null;
	}

	public QueueEntry onCronjob() throws TechException {
		SqlConn sqlConn = null;

		LockMgr lockMgr = context.getService().getLockMgr();
		lockMgr.waitUnlock(env.outMsgTable);

		try {
			SqlConnPoolManager conPoolMgr = (SqlConnPoolManager) BeanMgr
					.getInstance().get(ServiceConst.BEAN_SQL_CONN_POOL_MGR);
			SqlConnPool connPool = conPoolMgr.getSqlConnPool(env.connPoolName);
			sqlConn = connPool.getSqlConn();

			setOldMsgToFail(sqlConn);

			Map pRecord = new DBRow();
			pRecord.put(OutMsgTableConst.KEY_OUT_MSG_TABLE, env.outMsgTable);
			pRecord.put(OutMsgTableConst.COL_ASSIGN_STAT,
					OutMsgTableConst.VAL_ASSIGN_STAT_INIT);
			pRecord.put("MAX", env.maxMsgTableFetch);

			DataSet rRecords = sqlConn.queryList(
					"outTable.selectUnassignedOutMsg", pRecord);

			int size = rRecords.size();
			for (int msgIdx = 0; msgIdx < size; msgIdx++) {
				Map resultMap = rRecords.get(msgIdx);
				String dstIds = (String) resultMap
						.get(OutMsgTableConst.COL_DST_IDS);

				Map params = new DBRow();
				params.put(OutDstTableConst.KEY_OUT_DST_TABLE, env.outDstTable);
				params.put(OutMsgTableConst.COL_SEQ_NO,
						resultMap.get(OutMsgTableConst.COL_SEQ_NO));
				params.put(OutDstTableConst.COL_STAT,
						OutDstTableConst.VAL_STAT_INIT);

				// sqlConn.startTransaction();

				LoginIds loginIds = new LoginIds();

				if (OutDstTableConst.VAL_DST_ID_ALL.equals(dstIds)) {
					String[] ids = loginIds.getLoginIds(context
							.getServiceConfig().getServiceId());
					for (int idIdx = 0; idIdx < ids.length; idIdx++) {
						params.put(OutDstTableConst.COL_DST_ID, ids[idIdx]);
						params.put(OutDstTableConst.COL_DST_REG_DT,
								DateUtil.toString(System.currentTimeMillis()));
						sqlConn.queryUpdate("outTable.insertDstTable", params);
					}
				} else {
					String[] dstIdArr = StringUtil.splitWithoutEmpty(dstIds,
							",");
					for (int dstIdIdx = 0; dstIdIdx < dstIdArr.length; dstIdIdx++) {
						params.put(OutDstTableConst.COL_DST_ID,
								dstIdArr[dstIdIdx]);
						params.put(OutDstTableConst.COL_DST_REG_DT,
								DateUtil.toString(System.currentTimeMillis()));
						sqlConn.queryUpdate("outTable.insertDstTable", params);
					}
				}

				resultMap.put(OutMsgTableConst.KEY_OUT_MSG_TABLE,
						env.outMsgTable);
				resultMap.put(OutMsgTableConst.COL_ASSIGN_STAT,
						OutMsgTableConst.VAL_ASSIGN_STAT_ASSIGN);
				sqlConn.queryUpdate("outTable.updateMsgTableStat", resultMap);

				// sqlConn.commit();
			}

		} catch (BizException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} catch (TechException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} catch (SQLException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} finally {
			if (sqlConn != null) {
				sqlConn.close();
			}
		}
		return null;
	}

	private void setOldMsgToFail(SqlConn sqlConn) {
		try {
			if (env.maxAvailableMinutes <= 0 && env.maxSendCnt <= 0) {
				;
			} else {
				Map pRecord = new DBRow();
				pRecord.put(OutMsgTableConst.KEY_OUT_MSG_TABLE, env.outMsgTable);
				pRecord.put(OutDstTableConst.KEY_OUT_DST_TABLE, env.outDstTable);
				pRecord.put("STAT_FAIL", OutDstTableConst.VAL_STAT_FAIL);
				pRecord.put("STAT_SUCC", OutDstTableConst.VAL_STAT_SUCC);
				if (env.maxAvailableMinutes > 0) {
					pRecord.put(
							"TIMEOUT_DT",
							DateUtil.toString(System.currentTimeMillis()
									- (60000 * env.maxAvailableMinutes)));
				}
				if (env.maxSendCnt > 0) {
					pRecord.put("MAX_SEND_CNT", env.maxSendCnt);
				}
				pRecord.put("ERR_CD_TIMEOUT",
						OutDstTableConst.VAL_ERR_CD_TIMEOUT);
				pRecord.put("ERR_MSG_TIMEOUT",
						OutDstTableConst.VAL_ERR_MSG_TIMEOUT);
				pRecord.put("ERR_CD_MAX_SEND",
						OutDstTableConst.VAL_ERR_CD_MAX_SEND);
				pRecord.put("ERR_MSG_MAX_SEND",
						OutDstTableConst.VAL_ERR_MSG_MAX_SEND);

				sqlConn.queryUpdate("outTable.setOldMsgToFail", pRecord);
			}
		} catch (BizException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} catch (TechException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		} catch (SQLException e) {
			LOG.error(ExceptionDetail.getDetail(e));
		}
	}
}
