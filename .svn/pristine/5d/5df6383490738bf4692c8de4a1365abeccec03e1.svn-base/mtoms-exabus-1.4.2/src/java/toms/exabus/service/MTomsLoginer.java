package toms.exabus.service;

import msgrouter.api.interfaces.Message;
import msgrouter.api.interfaces.bean.ServerLoginer;
import msgrouter.engine.SessionContext;

import org.apache.log4j.Logger;

import elastic.util.util.TechException;

public class MTomsLoginer extends ServerLoginer {
	private static final Logger LOG = Logger.getLogger(MTomsLoginer.class);

	public String onMessage(Message msg, SessionContext context)
			throws TechException {
		String loginId = (String) msg.get("loginId");
		return loginId;
	}
}
