package toms.exabus.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import elastic.util.sqlmgr.SqlConn;
import elastic.util.util.BizException;
import elastic.util.util.TechException;

public interface SendInfo {
	public String getLastSeqnosSqlId();

	public String getUpdateLastSeqnoSqlId();

	public String getSeqnoColName();

	public String getRemoteSqlId();

	public List<List<Map>> getRemoteSqlParamRecords(SqlConn sqlConn, Map pRecord)
			throws BizException, TechException, SQLException;
}
