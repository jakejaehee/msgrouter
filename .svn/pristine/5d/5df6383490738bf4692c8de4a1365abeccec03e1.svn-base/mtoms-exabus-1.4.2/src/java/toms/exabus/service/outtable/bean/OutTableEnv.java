package toms.exabus.service.outtable.bean;

import toms.exabus.service.outtable.db.OutDstTableConst;
import toms.exabus.service.outtable.db.OutMsgTableConst;

public class OutTableEnv {

	public final String connPoolName;
	public final String outMsgTable;
	public final String outDstTable;
	public final int maxSendMsg;
	public final int maxSendCnt;
	public final int resendMinutes;
	public final int maxAvailableMinutes;
	public final int maxDstTableRowsToClean;
	public final int maxMsgTableFetch;

	public OutTableEnv(String connPoolName, String outMsgTable,
			String outDstTable, int maxSendMsg, int maxSendCnt,
			int maxAvailableMinutes, int resendMinutes,
			int maxDstTableRowsToClean, int maxMsgTableFetch) {
		this.connPoolName = connPoolName;

		if (outMsgTable == null) {
			outMsgTable = OutMsgTableConst.VAL_OUT_MSG_TABLE;
		}
		this.outMsgTable = outMsgTable;

		if (outDstTable == null) {
			outDstTable = OutDstTableConst.VAL_OUT_DST_TABLE;
		}
		this.outDstTable = outDstTable;

		this.maxSendMsg = maxSendMsg;

		this.maxSendCnt = maxSendCnt;

		this.resendMinutes = resendMinutes;

		this.maxAvailableMinutes = maxAvailableMinutes;

		this.maxDstTableRowsToClean = maxDstTableRowsToClean;

		this.maxMsgTableFetch = maxMsgTableFetch;
	}
}
