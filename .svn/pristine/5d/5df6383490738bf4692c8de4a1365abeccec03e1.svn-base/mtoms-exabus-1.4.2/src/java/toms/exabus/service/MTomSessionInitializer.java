package toms.exabus.service;

import msgrouter.engine.Service;
import msgrouter.engine.Session;
import msgrouter.engine.SessionInitializer;

import org.apache.log4j.Logger;

public class MTomSessionInitializer implements SessionInitializer {
	private static final Logger LOG = Logger
			.getLogger(MTomSessionInitializer.class);

	private Service service = null;
	private Session session = null;

	public void setService(Service service) throws Exception {
		this.service = service;
	}

	public void setSession(Session session) throws Exception {
		this.session = session;
	}

	public void execute() throws Exception {
	}
}
