package toms.exabus.service.outtable.db;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import elastic.util.sqlmgr.SqlConn;
import elastic.util.sqlmgr.dataset.DBRow;
import elastic.util.util.BizException;
import elastic.util.util.DateUtil;
import elastic.util.util.TechException;

public class OutTableWriter {
	private static final Logger LOG = Logger.getLogger(OutTableWriter.class);

	private final SqlConn sqlConn;

	public OutTableWriter(SqlConn sqlConn) {
		this.sqlConn = sqlConn;
	}

	/**
	 * ExaBus를 통해 발송할 메시지를 OUT MSG TABLE에 입력한다. ExaBus는 OUT MSG TABLE을 감시하다가 새로운
	 * 메시지 레코드가 있으면 해당 Daemon의 모든 ExaBus ID들에게 발송한다.
	 * 
	 * @param outMsgTableName
	 *            OUT MSG TABLE의 실제 DB 테이블명. null일 경우에는 기본값으로
	 *            "T_EXABUS_OUT_MSG_H" 이다.
	 * @param msgType
	 *            전송할 메시지의 타입이며 ExaBus에서는 이 메시지 타입을 판별하여 processMap.xml에 매핑된 빈을
	 *            실행하게 된다.
	 * @param msg
	 *            전송할 메시지이며 JSON 형식이어야 한다.
	 * @param userColumns
	 *            OUT TABLE의 기본필수 칼럼들 외에 사후 처리를 위하여 필요한 칼럼들을 OUT TABLE에 생성하고
	 *            userColumns 에 입력을 하면 사용자가 정의한 칼럼에 저장된다. 단, 해당 sqlId에 해당 사용자정의
	 *            칼럼들에 대한 처리 로직도 사전에 구현해두어야 한다.
	 * @throws TechException
	 * @throws SQLException
	 */
	public void writeToAll(String outMsgTableName, String msgType, String msg,
			Map userColumns) throws BizException, TechException, SQLException {
		write(outMsgTableName, null, msgType, msg, userColumns);
	}

	/**
	 * ExaBus를 통해 발송할 메시지를 OUT MSG TABLE에 입력한다. ExaBus는 OUT MSG TABLE을 감시하다가 새로운
	 * 메시지 레코드가 있으면 주어진 목적지 ID들에게 발송한다.
	 * 
	 * @param outMsgTableName
	 *            OUT MSG TABLE의 실제 DB 테이블명. null일 경우에는 기본값으로
	 *            "T_EXABUS_OUT_MSG_H" 이다.
	 * @param dstIds
	 *            전송대상 즉, 수신측 ExaBus의 ID 목록이다. 콤마(',')로 구분한다. 예.
	 *            "S001,S002,S007"
	 * @param msgType
	 *            전송할 메시지의 타입이며 ExaBus에서는 이 메시지 타입을 판별하여 processMap.xml에 매핑된 빈을
	 *            실행하게 된다.
	 * @param msg
	 *            전송할 메시지이며 JSON 형식이어야 한다.
	 * @param userColumns
	 *            OUT TABLE의 기본필수 칼럼들 외에 사후 처리를 위하여 필요한 칼럼들을 OUT TABLE에 생성하고
	 *            userColumns 에 입력을 하면 사용자가 정의한 칼럼에 저장된다. 단, 해당 sqlId에 해당 사용자정의
	 *            칼럼들에 대한 처리 로직도 사전에 구현해두어야 한다.
	 * @throws TechException
	 * @throws SQLException
	 */
	public void write(String outMsgTableName, List<String> dstIds,
			String msgType, String msg, Map userColumns) throws BizException,
			TechException, SQLException {
		if (LOG.isTraceEnabled()) {
			LOG.trace("msg: " + msg);
		}

		if (outMsgTableName == null) {
			outMsgTableName = OutMsgTableConst.VAL_OUT_MSG_TABLE;
		}

		String dstIdsStr = null;
		if (dstIds != null && dstIds.size() > 0) {
			StringBuffer sb = new StringBuffer();
			int size = dstIds.size();
			for (int i = 0; i < size; i++) {
				if (i > 0) {
					sb.append(",");
				}
				sb.append((String) dstIds.get(i));
			}
			dstIdsStr = sb.toString();
		} else {
			dstIdsStr = OutDstTableConst.VAL_DST_ID_ALL;
		}

		Map pRecord = new DBRow();
		pRecord.putAll(userColumns);
		pRecord.put(OutMsgTableConst.KEY_OUT_MSG_TABLE, outMsgTableName);
		pRecord.put(OutMsgTableConst.COL_DST_IDS, dstIdsStr);
		pRecord.put(OutMsgTableConst.COL_MSG_TYPE, msgType);
		pRecord.put(OutMsgTableConst.COL_MSG, msg);
		pRecord.put(OutMsgTableConst.COL_ASSIGN_STAT,
				OutMsgTableConst.VAL_ASSIGN_STAT_INIT);
		pRecord.put(OutMsgTableConst.COL_MSG_REG_DT,
				DateUtil.toString(System.currentTimeMillis()));

		sqlConn.startTransaction();
		sqlConn.queryUpdate("outTable.insertOutTable", pRecord);
		sqlConn.commit();
	}
}
