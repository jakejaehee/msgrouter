package toms.exabus.service;

import msgrouter.engine.Service;
import msgrouter.engine.Session;
import msgrouter.engine.SessionCloser;

public class MTomsSessionCloser implements SessionCloser {
	private Service service = null;
	private Session session = null;

	public void setService(Service service) throws Exception {
		this.service = service;
	}

	public void setSession(Session session) throws Exception {
		this.session = session;
	}

	public void execute() throws Exception {
	}
}
