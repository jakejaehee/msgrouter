package toms.exabus.service.toms1.bean;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import toms.exabus.service.SendInfo;
import elastic.util.sqlmgr.SqlConn;
import elastic.util.util.BizException;
import elastic.util.util.TechException;

public class Tom1ExtOrdSendInfo implements SendInfo {
	public String getLastSeqnosSqlId() {
		return "toms1ExtOrd.selectOrdSeqnos";
	}

	public String getUpdateLastSeqnoSqlId() {
		return "toms1ExtOrd.selectSettDtlSeqnos";
	}

	public String getSeqnoColName() {
		return "ORD_SEQNO";
	}

	public String getRemoteSqlId() {
		return "toms1PosSync.insertOrdOrd,toms1PosSync.insertOrdOrdDtl,toms1PosSync.insertOrdSettDtl";
	}

	public List<List<Map>> getRemoteSqlParamRecords(SqlConn sqlConn, Map pRecord)
			throws BizException, TechException, SQLException {
		List<Map> ordRecords = sqlConn.queryList("toms1ExtOrd.selectOrdOrd",
				pRecord);
		List<Map> ordDtlRecords = sqlConn.queryList(
				"toms1ExtOrd.selectOrdOrdDtl", pRecord);
		List<Map> settDtlRecords = sqlConn.queryList(
				"toms1ExtOrd.selectOrdSettDtl", pRecord);

		List<List<Map>> outTablePRecords = new ArrayList<List<Map>>();
		outTablePRecords.add(ordRecords);
		outTablePRecords.add(ordDtlRecords);
		outTablePRecords.add(settDtlRecords);
		return outTablePRecords;
	}
}
