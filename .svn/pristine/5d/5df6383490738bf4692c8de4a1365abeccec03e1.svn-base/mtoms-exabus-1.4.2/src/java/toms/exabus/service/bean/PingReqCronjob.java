package toms.exabus.service.bean;

import msgrouter.adapter.json.JSONMessage;
import msgrouter.api.QueueEntry;
import msgrouter.api.interfaces.Message;
import msgrouter.api.interfaces.bean.AsyncBean;
import msgrouter.engine.SessionContext;
import elastic.util.util.TechException;

public class PingReqCronjob extends AsyncBean {

	private static final long serialVersionUID = -2868716874420843852L;

	private SessionContext context = null;

	public void setSessionContext(SessionContext context) {
		this.context = context;
	}

	public QueueEntry onMessage(Message msg) throws TechException {
		return null;
	}

	public QueueEntry onCronjob() throws TechException {
		if (System.currentTimeMillis() - context.getLastIOTime() < 60000) {
			return null;
		}

		Message oMsg = new JSONMessage();
		oMsg.setMessageType("pingReq");

		QueueEntry qe = new QueueEntry();
		qe.addMessage(oMsg);
		return qe;
	}
}
