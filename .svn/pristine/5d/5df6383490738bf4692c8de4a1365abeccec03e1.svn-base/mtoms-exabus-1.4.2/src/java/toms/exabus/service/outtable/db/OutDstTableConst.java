package toms.exabus.service.outtable.db;

public class OutDstTableConst {

	public static final String COL_DST_ID = "DST_ID";
	public static final String COL_DST_REG_DT = "DST_REG_DT";
	public static final String COL_STAT = "STAT";
	public static final String COL_SENT_CNT = "SENT_CNT";
	public static final String COL_SENT_DT = "SENT_DT";
	public static final String COL_RECV_DT = "RECV_DT";
	public static final String COL_ERR_CD = "ERR_CD";
	public static final String COL_ERR_MSG = "ERR_MSG";

	public static final String VAL_DST_ID_ALL = "@ALL@";

	public static final String VAL_ERR_CD_MAX_SEND = "ERR-001";
	public static final String VAL_ERR_MSG_MAX_SEND = "MAX SEND";

	public static final String VAL_ERR_CD_TIMEOUT = "ERR-002";
	public static final String VAL_ERR_MSG_TIMEOUT = "TIMEOUT";

	public static final String VAL_STAT_INIT = "I";
	public static final String VAL_STAT_PROC = "P";
	public static final String VAL_STAT_SENT = "S";
	public static final String VAL_STAT_RECV = "R";
	public static final String VAL_STAT_BACK = "B";
	public static final String VAL_STAT_SUCC = "O";
	public static final String VAL_STAT_FAIL = "X";

	public static final String KEY_OUT_DST_TABLE = "OUT_DST_TABLE";
	public static final String VAL_OUT_DST_TABLE = "T_EXABUS_OUT_DST_H";
}
