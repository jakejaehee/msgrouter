package toms.exabus.service.outtable.bean;

import java.util.List;
import java.util.Map;

import msgrouter.api.interfaces.Message;
import msgrouter.api.interfaces.bean.SentTrigger;
import msgrouter.engine.SessionContext;

import org.apache.log4j.Logger;

import toms.exabus.service.ServiceConst;
import toms.exabus.service.outtable.db.OutDstTableConst;
import toms.exabus.service.outtable.db.OutMsgTableConst;
import elastic.util.beanmgr.BeanMgr;
import elastic.util.concurrent.LockMgr;
import elastic.util.sqlmgr.SqlConn;
import elastic.util.sqlmgr.SqlConnPool;
import elastic.util.sqlmgr.SqlConnPoolManager;
import elastic.util.sqlmgr.dataset.DBRow;
import elastic.util.util.DateUtil;
import elastic.util.util.ErrorCodeMgr;
import elastic.util.util.TechException;

public class OutTableSendTrigger extends SentTrigger {
	private static final long serialVersionUID = -349625856050917849L;

	private static final Logger LOG = Logger
			.getLogger(OutTableSendTrigger.class);

	private final OutTableEnv env;
	private ErrorCodeMgr errorCodeMgr = null;
	private SessionContext context = null;

	public OutTableSendTrigger() {
		this.env = (OutTableEnv) BeanMgr.getInstance().get("outTableEnv");
		this.errorCodeMgr = (ErrorCodeMgr) BeanMgr.getInstance().get(
				"errorCodeMgr");
	}

	public void setSessionContext(SessionContext context) {
		this.context = context;
	}

	public void execute(Message sentMsg) throws TechException {
		SqlConn sqlConn = null;

		LockMgr lockMgr = context.getService().getLockMgr();
		lockMgr.waitUnlock(env.outMsgTable);

		try {
			SqlConnPoolManager conPoolMgr = (SqlConnPoolManager) BeanMgr
					.getInstance().get(ServiceConst.BEAN_SQL_CONN_POOL_MGR);

			SqlConnPool connPool = conPoolMgr.getSqlConnPool(env.connPoolName);
			sqlConn = connPool.getSqlConn();

			Object seqNo = sentMsg.get(OutMsgTableConst.COL_SEQ_NO);
			String dstId = (String) sentMsg.get(OutDstTableConst.COL_DST_ID);

			if (seqNo == null || dstId == null) {
				return;
			}

			Map pRecord = new DBRow();
			pRecord.put(OutMsgTableConst.KEY_OUT_MSG_TABLE, env.outMsgTable);
			pRecord.put(OutDstTableConst.KEY_OUT_DST_TABLE, env.outDstTable);
			pRecord.put(OutMsgTableConst.COL_SEQ_NO, seqNo);
			pRecord.put(OutDstTableConst.COL_DST_ID, dstId);
			pRecord.put(OutDstTableConst.COL_STAT,
					OutDstTableConst.VAL_STAT_SENT);
			pRecord.put("STAT_PROC", OutDstTableConst.VAL_STAT_PROC);
			pRecord.put(OutDstTableConst.COL_SENT_DT,
					DateUtil.toString(System.currentTimeMillis()));

			int rows = sqlConn.queryUpdate("outTable.setSent", pRecord);

			if (rows <= 0) {
				List<Map> rRecords = sqlConn.queryList(
						"outTable.selectSeqNoByBakSeqNo", pRecord);
				if (rRecords != null && rRecords.size() > 0) {
					Map rRecord = rRecords.get(0);
					seqNo = rRecord.get(OutMsgTableConst.COL_SEQ_NO);

					pRecord.put(OutMsgTableConst.COL_SEQ_NO, seqNo);
					pRecord.put(OutDstTableConst.COL_SENT_DT,
							DateUtil.toString(System.currentTimeMillis()));
					sqlConn.queryUpdate("outTable.setSent", pRecord);
				}
			}
		} catch (TechException e) {
			throw e;
		} catch (Exception e) {
			throw new TechException(e);
		} finally {
			if (sqlConn != null) {
				sqlConn.close();
			}
		}
	}
}
