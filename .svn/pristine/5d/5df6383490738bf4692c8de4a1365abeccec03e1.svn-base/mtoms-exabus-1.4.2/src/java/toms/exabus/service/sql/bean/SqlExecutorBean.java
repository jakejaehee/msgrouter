package toms.exabus.service.sql.bean;

import java.util.List;

import msgrouter.adapter.json.JSONMessage;
import msgrouter.api.QueueEntry;
import msgrouter.api.interfaces.Message;
import msgrouter.api.interfaces.bean.AsyncBean;
import msgrouter.engine.SessionContext;

import org.apache.log4j.Logger;

import toms.exabus.service.ServiceConst;
import toms.exabus.service.outtable.db.OutDstTableConst;
import toms.exabus.service.outtable.db.OutMsgTableConst;
import elastic.util.beanmgr.BeanMgr;
import elastic.util.json.JSONObject;
import elastic.util.sqlmgr.SqlConn;
import elastic.util.sqlmgr.SqlConnPool;
import elastic.util.sqlmgr.SqlConnPoolManager;
import elastic.util.sqlmgr.SqlMgrUtil;
import elastic.util.util.ErrorCodeMgr;
import elastic.util.util.ExceptionDetail;
import elastic.util.util.TechException;
import elastic.util.xml.XmlReader;

public class SqlExecutorBean extends AsyncBean {
	private static final long serialVersionUID = 4979714053621328849L;

	private static final Logger LOG = Logger.getLogger(SqlExecutorBean.class);

	private ErrorCodeMgr errorCodeMgr = null;
	private XmlReader config = null;
	private SessionContext context = null;

	public SqlExecutorBean() {
		errorCodeMgr = (ErrorCodeMgr) BeanMgr.getInstance().get("errorCodeMgr");
		config = (XmlReader) BeanMgr.getInstance().get("config");
	}

	public void setSessionContext(SessionContext context) {
		this.context = context;
	}

	public QueueEntry onMessage(Message msg) throws TechException {
		QueueEntry qe = new QueueEntry();
		SqlConn sqlConn = null;

		Object seqNo = msg.get(OutMsgTableConst.COL_SEQ_NO);
		String dstId = (String) msg.get(OutDstTableConst.COL_DST_ID);

		JSONObject sqlExecMapJSON = (JSONObject) msg
				.get(OutMsgTableConst.COL_MSG);

		try {
			String sqlId = (String) sqlExecMapJSON.get("sqlId");
			Object recordsObj = sqlExecMapJSON.get("records");
			List pRecords = SqlMgrUtil.jsonToList(recordsObj);

			SqlConnPoolManager conPoolMgr = (SqlConnPoolManager) BeanMgr
					.getInstance().get(ServiceConst.BEAN_SQL_CONN_POOL_MGR);
			SqlConnPool connPool = conPoolMgr
					.getSqlConnPool(ServiceConst.VAL_SQL_CONN_POOL);
			sqlConn = connPool.getSqlConn();

			sqlConn.startTransaction();

			sqlConn.queryUpdate(sqlId, pRecords);

			Message sendMsgJSON = new JSONMessage();
			if (ServiceConst.MSG_TYPE_OUT_TABLE_REQ
					.equals(msg.getMessageType())) {
				sendMsgJSON.setMessageType(ServiceConst.MSG_TYPE_OUT_TABLE_RES);
			} else if (ServiceConst.MSG_TYPE_TOM10_SAL_SEND_REQ.equals(msg
					.getMessageType())) {
				sendMsgJSON
						.setMessageType(ServiceConst.MSG_TYPE_TOM10_SAL_SEND_RES);
			}
			sendMsgJSON.set(OutMsgTableConst.COL_SEQ_NO, seqNo);
			sendMsgJSON.set(OutDstTableConst.COL_DST_ID, dstId);
			sendMsgJSON.set(OutDstTableConst.COL_STAT,
					OutDstTableConst.VAL_STAT_SUCC);

			sqlConn.commit();

			qe.addMessage(sendMsgJSON);
		} catch (Exception e) {
			LOG.error(ExceptionDetail.getDetail(e));

			Message sendMsgJSON = new JSONMessage();
			if (ServiceConst.MSG_TYPE_OUT_TABLE_REQ
					.equals(msg.getMessageType())) {
				sendMsgJSON.setMessageType(ServiceConst.MSG_TYPE_OUT_TABLE_RES);
			} else if (ServiceConst.MSG_TYPE_TOM10_SAL_SEND_REQ.equals(msg
					.getMessageType())) {
				sendMsgJSON
						.setMessageType(ServiceConst.MSG_TYPE_TOM10_SAL_SEND_RES);
			}
			sendMsgJSON.set(OutMsgTableConst.COL_SEQ_NO, seqNo);
			sendMsgJSON.set(OutDstTableConst.COL_DST_ID, dstId);
			sendMsgJSON.set(OutDstTableConst.COL_STAT,
					OutDstTableConst.VAL_STAT_FAIL);
			sendMsgJSON.set(OutDstTableConst.COL_ERR_CD, "ERR-999");
			sendMsgJSON.set(OutDstTableConst.COL_ERR_MSG, e.getMessage());

			qe.addMessage(sendMsgJSON);
		} finally {
			if (sqlConn != null) {
				sqlConn.close();
			}
		}

		return qe;
	}

	public QueueEntry onCronjob() throws TechException {
		return null;
	}
}
