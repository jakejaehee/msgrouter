package toms.exabus.service.toms1.bean;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import toms.exabus.service.SendInfo;
import elastic.util.sqlmgr.SqlConn;
import elastic.util.util.BizException;
import elastic.util.util.TechException;

public class Toms1OrdSendInfo implements SendInfo {
	public String getLastSeqnosSqlId() {
		return "toms1Ord.selectSettDtlSeqnos";
	}

	public String getUpdateLastSeqnoSqlId() {
		return "toms1Ord.updateLastSettDtlSeqno";
	}

	public String getSeqnoColName() {
		return "SETT_DTL_SEQNO";
	}

	public String getRemoteSqlId() {
		return "toms1PosSync.insertOrdOrd,toms1PosSync.insertOrdOrdDtl,toms1PosSync.insertOrdSettDtl";
	}

	public List<List<Map>> getRemoteSqlParamRecords(SqlConn sqlConn, Map pRecord)
			throws BizException, TechException, SQLException {
		List<Map> ordRecords = sqlConn.queryList("toms1Ord.selectOrdOrd",
				pRecord);
		List<Map> ordDtlRecords = sqlConn.queryList("toms1Ord.selectOrdOrdDtl",
				pRecord);
		List<Map> settDtlRecords = sqlConn.queryList(
				"toms1Ord.selectOrdSettDtl", pRecord);

		List<List<Map>> outTablePRecords = new ArrayList<List<Map>>();
		outTablePRecords.add(ordRecords);
		outTablePRecords.add(ordDtlRecords);
		outTablePRecords.add(settDtlRecords);
		return outTablePRecords;
	}
}
